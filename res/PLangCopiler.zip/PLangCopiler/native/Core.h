//
// Created by prw on 16.04.2020.
//

#ifndef MT_TEST_CORE_H
#define MT_TEST_CORE_H

int* getPointer(){
    return new int(11);
}

void needPointer(int* t){

}


#endif //MT_TEST_CORE_H
